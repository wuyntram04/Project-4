#pragma once
#include<cmath>
#include<sstream>
using namespace std;

class Complex
{
private:
	float* realNum;
	float* iNum;
public:
	const float EPS = 1e-6f;

	//Default Constructor
	// Precondition: none
   // Postcondition: realNum and iNum are allocated and initialized to 0
	Complex() {
		realNum = new float(0.0);
		iNum = new float(0.0);
	}

	// Precondition: none
    // Postcondition: realNum and iNum are allocated, set to r and i
	Complex(float r, float i)
	{
		realNum = new float(r);
		iNum = new float(i);
	}

	//Destructor
	// Precondition: realNum and iNum point to dynamically allocated memory
    // Postcondition: memory for realNum and iNum is released
	~Complex() {
		delete realNum;
		delete iNum;
	}

	//Copy Constructor
	// Precondition: other is a valid Complex object
    // Postcondition: creates a new Complex object with same values as other
	Complex(const Complex& other)
	{
		realNum = new float(*other.realNum);
		iNum = new float(*other.iNum);
	}

	// Set real part
	// Precondition: realNum is allocated
    // Postcondition: *realNum == real
	void setRealNum(float real)
	{
		*realNum = real;
	}

	// Get real part
    // Precondition: realNum is allocated
   // Postcondition: returns the value stored in *realNum
	float getRealNum() const
	{
		return *realNum;
	}

	// Set imaginary part
	// Precondition: iNum is allocated
	// Postcondition: *iNum == i
	void setiNum(float i)
	{
		*iNum = i;
	}

	// Get imaginary part
	// Precondition: iNum is allocated
	// Postcondition: returns *iNum
	float getiNum() const
	{
		return *iNum;
	}

	//////////////////////==============MENU A============////////////////////////////

	// Negation
	// Precondition: object is valid
	// Postcondition: returns a new Complex(-real, -imag)
	Complex negate() const {
		return Complex(-(*realNum), -(*iNum));
	}
	
	// Unary minus operator
	// Precondition: object is valid
	// Postcondition: returns same result as negate()
	Complex operator -() const
	{
		return negate();
	}

	// Add scalar
	// Precondition: object is valid
	// Postcondition: returns (real + k, imag)
	Complex operator +(float k) const
	{
		return Complex(k + *realNum, *iNum);
	}

	// Subtract scalar
	// Precondition: object is valid
	// Postcondition: returns (real - k, imag)
	Complex operator -(float k) const
	{
		return Complex(*realNum - k, *iNum);
	}

	// Multiply by scalar
	// Precondition: object is valid
	// Postcondition: returns (real*k, imag*k)
	Complex operator *(float k) const 
	{
		return Complex( *realNum * k, *iNum * k);
	}

	// Divide by scalar
   // Precondition: fabs(k) > EPS
   // Postcondition: returns (real/k, imag/k); if k ? 0, returns (0,0)
	Complex operator /(float k) const
	{
		if (fabs(k) <= EPS) {
			return Complex(0.0f, 0.0f);
		}
		return Complex(*realNum / k, *iNum / k);
	}

	// Negate a complex number
   // Precondition: c1 is a valid Complex object
   // Postcondition: prints the negated value of c1 without modifying c1
	static void Negate(const Complex& c1)
	{
		Complex c2 = -c1;
		cout << "\n\t\tNegated the complex number C2 (a copy of C1)\n";
		cout << "\t\t-(" << c1.toString() << ") = " << c2.toString();
	}

	// Add a scalar to a complex number
   // Precondition: c1 is a valid Complex object; user inputs a valid float/double value
   // Postcondition: prints the result of c1 + value and value + c1 without modifying c1
	static void AddComplex(const Complex& c1)
	{
		float value = inputDouble("\n\tEnter a value (double): ");
		cout << "\n\t\tC1 + value ";
		Complex add = c1 + value;
		cout << "\n\t\t(" << c1.toString() << ") + " << value << " = " << add.toString();

		cout << "\n\n\t\tValue + C1";
		cout << "\n\t\t" << value << " + (" << c1.toString() << ") = " << add.toString();
	}

	// Multiply a complex number by a scalar
   // Precondition: c1 is a valid Complex object; user inputs a valid float/double value
  // Postcondition: prints the result of c1 * value and value * c1 without modifying c1
	static void MultiComplex(const Complex& c1)
	{
		float value = inputDouble("\n\tEnter a value (double): ");
		cout << "\n\t\tC1 * value ";
		Complex mul1 = c1 * value;
		cout << "\n\t\t(" << c1.toString() << ") * " << value << " = " << mul1.toString();

		cout << "\n\n\t\tValue * C1";
		Complex mul2 = value * c1;
		cout << "\n\t\t" << value << " * (" << c1.toString() << ") = " << mul2.toString();
	}

	/*static void SubComplex(const Complex& c1)
	{
		float value = inputDouble("\n\tEnter a value (double): ");
		cout << "\n\t\tC1 - value ";
		Complex sub1 = c1 - value;
		cout << "\n\t\t(" << c1.toString() << ") - " << value << " = " << sub1.toString();

		cout << "\n\n\t\tValue - C1";
		Complex sub2 = value - c1;
		cout << "\n\t\t" << value << " - (" << c1.toString() << ") = " << sub2.toString();
	}

	static void MultiComplex(const Complex& c1)
	{
		float value = inputDouble("\n\tEnter a value (double): ");
		cout << "\n\t\tC1 * value ";
		Complex mul1 = c1 * value;
		cout << "\n\t\t(" << c1.toString() << ") * " << value << " = " << mul1.toString();

		cout << "\n\n\t\tValue * C1";
		Complex mul2 = value * c1;
		cout << "\n\t\t" << value << " * (" << c1.toString() << ") = " << mul2.toString();
	}

	static void DivComplex(const Complex& c1)
	{
		float value = inputDouble("\n\tEnter a value (double): ");
		cout << "\n\t\tC1 / value ";
		Complex div1 = c1 / value;
		cout << "\n\t\t(" << c1.toString() << ") / " << value << " = " << div1.toString();

		cout << "\n\n\t\tValue / C1";
		Complex div2 = value / c1;
		cout << "\n\t\t" << value << " / (" << c1.toString() << ") = " << div2.toString();
	}*/

	//////////////////////==============OUTPUT============////////////////////////////
	// Convert to string
	// Precondition: object is valid
	// Postcondition: returns formatted string: "0", "a", "bi", or "a � bi"
	string toString() const
	{
		ostringstream out;

		float re = *realNum;
		float im = *iNum;

		// Treat tiny values as 0
		if (fabs(re) <= EPS) re = 0.0f;
		if (fabs(im) <= EPS) im = 0.0f;

		// Case 1: both zero
		if (re == 0.0f && im == 0.0f)
		{
			out << "0";
		}
		// Case 2: imaginary zero  just real
		else if (im == 0.0f) {
			out << re;
		}
		// Case 3: real zero  just imaginary
		else if (re == 0.0f)
		{
			out << im << "i";
		}
		// Case 4: both present  force pretty "a � bi"
		else {
			out << re;
			if (im >= 0)
				out << " + " << im << "i";       // positive imaginary
			else
				out << " - " << fabs(im) << "i"; // negative imaginary
		}

		return out.str();
	}

	//////////////////////==============MENU B============////////////////////////////

	//////////////////////==============INPUT================//////////////////////
	 // Input complex number
	// Precondition: user provides valid numeric input
	// Postcondition: *realNum and *iNum updated with input values
	void setComplex()
	{
		*realNum = static_cast<float>(inputDouble("\n\tEnter a number(double value) for the real part : "));
		*iNum = static_cast<float>(inputDouble("\n\tEnter a number(double value) for the imaginary part : "));
	}

	////////////////////// ---------- Operators ----------///////////////////////
	// Add two complex numbers
	// Precondition: both operands valid
	// Postcondition: returns (a+c, b+d)
	Complex operator+(const Complex& other) const
	{
		return Complex(getRealNum() + other.getRealNum(),
			getiNum() + other.getiNum());
	}

	// Subtract two complex numbers
	// Precondition: both operands valid
	// Postcondition: returns (a-c, b-d)
	Complex operator-(const Complex& other) const {
		return Complex(getRealNum() - other.getRealNum(),
			getiNum() - other.getiNum());
	}

	// Multiply two complex numbers
	// Precondition: both operands valid
	// Postcondition: returns (a*c - b*d, a*d + b*c)
	Complex operator*(const Complex& other) const {
		float a = getRealNum(), b = getiNum();
		float c = other.getRealNum(), d = other.getiNum();
		return Complex(a * c - b * d, a * d + b * c);
	}

	// Divide two complex numbers
	// Precondition: denominator (c^2+d^2) > EPS
	// Postcondition: returns correct division; if denom ? 0, returns (0,0)
	Complex operator/(const Complex& other) const {
		float c = other.getRealNum(), d = other.getiNum();
		float denom = c * c + d * d;
		if (denom <= EPS)
		{
			/*cout << "\n\n\t\tERROR: Division by zero complex number.\n";*/
			return Complex(0.0f, 0.0f);
		}
		float a = getRealNum(), b = getiNum();
		return Complex((a * c + b * d) / denom,
			(b * c - a * d) / denom);
	}

	///////////////////================ Scalar ops ================////////////////////////
	/*Complex operator*(float k) const
	{
		return Complex(getRealNum() * k, getiNum() * k);
	}

	Complex operator/(float k) const
	{
		if (fabs(k) <= EPS)
		{
			cout << "\n\tERROR: Division by zero scalar.\n";
			return Complex(0.0f, 0.0f);
		}
		return Complex(getRealNum() / k, getiNum() / k);
	}*/

	friend Complex operator*(float k, const Complex& z) { return z * k; }

	///////////////////// ---------- Comparisons --------------------///////////////////
	// Equality operator
	// Precondition: both operands valid
	// Postcondition: returns true if |a-c|<=EPS and |b-d|<=EPS
	bool operator==(const Complex& other) const
	{
		return fabs(getRealNum() - other.getRealNum()) <= EPS &&
			fabs(getiNum() - other.getiNum()) <= EPS;
	}
	
	// Inequality operator
	// Precondition: both operands valid
	// Postcondition: returns logical negation of operator==
	bool operator!=(const Complex& other) const { return !(*this == other); }

	////////////////////// ---------- Menu Helpers ------------------////////////////////////
	
	// Verify equality and inequality between two Complex numbers
	// Precondition: C1 and C2 are valid Complex objects
	// Postcondition: prints results of (C1 == C2) and (C2 != C1)
	static void verifyComparisons(const Complex& C1, const Complex& C2)
	{
		cout << "\n\t\tC1 == C2 -> (" << C1.toString() << ") == ("
			<< C2.toString() << ") ? " << (C1 == C2 ? "true" : "false");
		cout << "\n\t\tC2 != C1 -> (" << C2.toString() << ") != ("
			<< C1.toString() << ") ? " << (C2 != C1 ? "true" : "false") << "\n";
	}

	// Evaluate +, -, *, and / between two Complex numbers
	// Precondition: C1 and C2 are valid Complex objects
	// Postcondition: prints results of addition, subtraction, multiplication,
	//                and division (prints "undefined" if divisor is near 0)
	static void evaluateArithmetic(const Complex& C1, const Complex& C2)
	{
		Complex sum = C1 + C2;
		Complex diff = C2 - C1;
		Complex prod = C1 * C2;


		cout << "\n\t\tAddition\t: C1 + C2 -> (" << C1.toString()
			<< ") + (" << C2.toString() << ") = " << sum.toString();
		cout << "\n\t\tSubtraction\t: C2 - C1 -> (" << C2.toString()
			<< ") - (" << C1.toString() << ") = " << diff.toString();
		cout << "\n\t\tMultiplication\t: C1 * C2 -> (" << C1.toString()
			<< ") * (" << C2.toString() << ") = " << prod.toString();
		if (fabs(C1.getRealNum()) < C1.EPS && fabs(C1.getiNum()) < C1.EPS) {
			cout << "\n\t\tDivision\t: C2 / C1 -> (" << C2.toString()
				<< ") / (" << C1.toString() << ") = undefined\n";
		}
		else {
			Complex quot = C2 / C1;
			cout << "\n\t\tDivision\t: C2 / C1 -> (" << C2.toString()
				<< ") / (" << C1.toString() << ") = " << quot.toString() << "\n";
		}

	}

	// Evaluate custom expression with step-by-step output
	// Precondition: C1 and C2 are valid Complex objects
	// Postcondition: prints each step of the expression
	//                (3 * (C1 + C2) / 7) / (C2 - C1/9) != C3
	static void evaluateExpression(const Complex& C1, const Complex& C2) {
		Complex C3(1.07109f, 0.120832f);

		cout << "\n\t\tC1 = " << C1.toString()
			<< "\n\t\tC2 = " << C2.toString()
			<< "\n\t\tC3 = " << C3.toString();

		cout << "\n\n\t\tEvaluating expression..."
			<< "\n\t\t\t   (3 * (C1 + C2) / 7) / (C2 - C1 / 9) != (" << C3.toString() << ") ?";

		// Step 1: C1 + C2
		Complex sum = C1 + C2;

		Complex step1_den = C1 / 9.0f;
		cout << "\n\t\t  step #1: (3 * (" << sum.toString()
			<< ") / 7) / (C2 - (" << step1_den.toString() << ")) != (" << C3.toString() << ")";

		// Step 2: numerator divide by 7
		Complex step1_num = 3 * sum;
		Complex step2_C2 = C2 - step1_den;
		Complex step2_num = step1_num / 7.0f;
		cout << "\n\t\t  step #2: ((" << step1_num.toString()
			<< ") / 7) / (" << step2_C2.toString() << ") != (" << C3.toString() << ")";

		// Step 3: numerator / denominator
		Complex step3 = step2_num / step2_C2;
		cout << "\n\t\t  step #3: (" << step2_num.toString() << ") / (" << step2_C2.toString()
			<< ") != (" << C3.toString() << ")";

		//Step 4: 
		cout << "\n\t\t  step #4: (" << step3.toString() << ") != (" << C3.toString() << ")";

		// Step 5: Final comparison
		bool result = (step3 != C3);
		cout << "\n\t\t  step #5: " << (result ? "true" : "false") << "\n";
	}


};

// Scalar - Complex
// Precondition: c is valid
// Postcondition: returns (k - c.real, -c.imag)
Complex operator -(float k, const Complex& c) {
	return Complex(k - c.getRealNum(), -c.getiNum());
}

// Scalar / Complex
// Precondition: c is valid and not (0,0)
// Postcondition: returns scalar divided by complex;
//                if c ? 0, returns (NaN, NaN)
Complex operator /(float k, const Complex& c)
{
	float r = c.getRealNum();
	float i = c.getiNum();

	if (fabs(r) < 1e-6f && fabs(i) < 1e-6f)
	{
		return Complex(NAN, NAN);
	}

	float denom = r * r + i * i;
	float realPart = (k * r) / denom;
	float imagPart = (-k * i) / denom;

	return Complex(realPart, imagPart);
}



