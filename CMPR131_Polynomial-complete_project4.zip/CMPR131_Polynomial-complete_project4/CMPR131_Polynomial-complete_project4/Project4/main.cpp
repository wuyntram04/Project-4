#include <iostream>
#include "input.h"
#include "Complex.h"
#include "Rational.h"
#include "polynomial.h"

using namespace std;

//PROTOTYPE

void mainMenu();

// #1
void complexNumberMenu();
void complexMenuA();
void complexMenuB();

// #2
void RationalFunction();
void RationalFunctionA();
void RationalFunctionB();

// #3
void polynomialMenu();
void polynomial_optionA(polynomial &p);
void polynomial_optionB();

int main()
{
	mainMenu();
}

void mainMenu()
{
	while (true)
	{
		system("cls");

		cout << "\n\tCMPR131 Chapter4: Complex Numbers, Rational Numbers, Polynomials by Quynh, Tram, Khang, Minh & Thinh. (09/16/25)";
		cout << "\n\t" << string(80, char(205));
		cout << "\n\t\t1> Complex Numbers";
		cout << "\n\t\t2> Rational Numbers";
		cout << "\n\t\t3> Polynomials";
		cout << "\n\t" << string(80, char(196));
		cout << "\n\t\t0> exit";
		cout << "\n\t" << string(80, char(205));

		switch (inputChar("\n\t\tOption: ", static_cast<string>("1230")))
		{
		case '1':
			complexNumberMenu();
			break;
		case '2':
			RationalFunction();
			break;
		case '3':
			polynomialMenu();
			break;
		case '0':
			return;
		}
	}
}

void complexNumberMenu()
{


	do
	{
		system("cls");

		cout << "\n\tA complex number is a number that can be expressed in the form a + b i, where a and b are real";
		cout << "\n\tnumbers, and i represents the \"imaginary unit\", satisfying the equation i^2 = -1. Because no";
		cout << "\n\treal number satisfies this equation, i is called an imaginary number. For the complex number";
		cout << "\n\ta + b i, a is called the real part and b is called the imaginary part.";
		cout << "\n\n\t1> Complex Numbers";
		cout << "\n\t" << string(80, char(205));
		cout << "\n\t\tA> A Complex Number";
		cout << "\n\t\tB> Multiple Complex Numbers";
		cout << "\n\t" << string(80, char(196));
		cout << "\n\t\t0> return";
		cout << "\n\t" << string(80, char(205));


		switch (toupper(inputChar("\n\t\tOption: ")))
		{
		case 'A': complexMenuA();
			break;
		case 'B': complexMenuB();
			break;
		case '0':
			return;
		default:
			cout << "\n\tInvalid input";
			break;

		}

	} while (true);

}

void complexMenuA() {
	Complex c1;

	do
	{
		system("cls");

		cout << "\n\tA> A Complex Number";
		cout << "\n\t" << string(80, char(205));
		cout << "\n\t\t1. Enter the real number";
		cout << "\n\t\t2. Enter the imaginary number";
		cout << "\n\t\t3. Display the complex number";
		cout << "\n\t\t4. Negate the complex number";
		cout << "\n\t\t5. Add (+) the complex number with a constant";
		cout << "\n\t\t6. Subtract (-) the complex number with a constant";
		cout << "\n\t\t7. Multiply (*) the complex number with a constant";
		cout << "\n\t\t8. Divide (/) the complex number with a constant";
		cout << "\n\t" << string(80, char(196));
		cout << "\n\t\t0. return";
		cout << "\n\t" << string(80, char(205));

		switch (toupper(inputInteger("\n\t\tOption: ", 0, 8)))
		{
		case 1:
			c1.setRealNum(inputDouble("\n\tEnter a number (double value) for the real part: "));
			break;
		case 2:
			c1.setiNum(inputDouble("\n\tEnter a number (double value) for the imaginary part: "));
			break;
		case 3:
			cout << "\n\tComplex Number C1 = " << c1.toString();
			break;
		case 4:
		{
			Complex::Negate(c1);
			break;
		}
		case 5:
		{
			Complex::AddComplex(c1);
			break;
		}
		case 6:
		{
			float value = inputDouble("\n\tEnter a value (double): ");
			cout << "\n\t\tC1 - value ";
			Complex sub1 = c1 - value;
			cout << "\n\t\t(" << c1.toString() << ") - " << value << " = " << sub1.toString();

			cout << "\n\n\t\tValue - C1";
			Complex sub2 = value - c1;
			cout << "\n\t\t" << value << " - (" << c1.toString() << ") = " << sub2.toString();
			break;
		}
		case 7:
		{
			/*float value = inputDouble("\n\tEnter a value (double): ");
			cout << "\n\t\tC1 * value ";
			Complex mul1 = c1 * value;
			cout << "\n\t\t(" << c1.toString() << ") * " << value << " = " << mul1.toString();

			cout << "\n\n\t\tValue * C1";
			Complex mul2 = value * c1;
			cout << "\n\t\t" << value << " * (" << c1.toString() << ") = " << mul2.toString();*/
			Complex::MultiComplex(c1);
			break;
		}
		case 8:
		{
			float value = inputChar("\n\tEnter a value (double): ");
			cout << "\n\t\tC1 / value ";
			Complex div1 = c1 / value;
			cout << "\n\t\t(" << c1.toString() << ") / " << value << " = " << div1.toString();

			cout << "\n\n\t\tValue / C1";
			Complex div2 = value / c1;
			cout << "\n\t\t" << value << " / (" << c1.toString() << ") = " << div2.toString();
			break;
		}
		case 0:
			return;
		default:
			cout << "\n\tInvalid input";
			break;

		}
		cout << "\n\n\t";
		system("pause");

	} while (true);
}

void complexMenuB()
{
	Complex c1;
	Complex c2;

	do
	{
		system("cls");

		cout << "\n\tB> Multiple Complex Numbers";
		cout << "\n\t" << string(90, char(205));
		cout << "\n\t\t1. Enter complex number C1";
		cout << "\n\t\t2. Enter complex number C2";
		cout << "\n\t\t3. Verify condition operators (== and !=) of C1 and C2";
		cout << "\n\t\t4. Evaluate arithmatic operators (+, - , * and /) of C1 and C2";
		cout << "\n\t\t5. Evaluate steps in (3 * (C1 + C2) / 7) / (C2 - C1 / 9) != (1.07109 + 0.120832i) ?";
		cout << "\n\t" << string(90, char(196));
		cout << "\n\t\t0. return";
		cout << "\n\t" << string(90, char(205));

		switch (toupper(inputInteger("\n\t\tOption: ", 0, 8)))
		{
		case 1:
		{
			c1.setComplex();
			cout << "\n\tC1: " << c1.toString();
			break;
		}
		case 2:
		{
			c2.setComplex();
			cout << "\n\tC2: " << c2.toString();
			break;
		}
		case 3: Complex::verifyComparisons(c1, c2);
			break;
		case 4: Complex::evaluateArithmetic(c1, c2);
			break;
		case 5: Complex::evaluateExpression(c1, c2);
			break;
		case 0: return;
		default:
			cout << "\n\tInvalid input";
			break;

		}

		cout << "\n\n\t";
		system("pause");

	} while (true);
}

void RationalNumberMenu()
{
	cout << "\n\tA rational number is a number that can be written as a fraction, a/b, where a is numerator and";
	cout << "\n\tb is denominator. Rational numbers are all real numbers, and can be positive or negative. A";
	cout << "\n\tnumber that is not rational is called irrational. Most of the numbers that people use in everyday";
	cout << "\n\tlife are rational.These include fractions, integers and numbers with finite decimal digits.";
	cout << "\n\tIn general, a number that can be written as a fraction while it is in its own form is rational.";
	cout << "\n\n\t2> Rational Numbers";
	cout << "\n\t" << string(80, char(205));
	cout << "\n\t\tA> A Rational Number";
	cout << "\n\t\tB> Multiple Rational Numbers";
	cout << "\n\t" << string(80, char(196));
	cout << "\n\t\t0> return";
	cout << "\n\t" << string(80, char(205));
}


void RationalFunction()
{
	do
	{
		system("cls");
		RationalNumberMenu();
		switch (toupper(inputChar("\n\t\tOption: ")))
		{
		case 'A':
			RationalFunctionA();
			break;
		case 'B': RationalFunctionB();
			break;
		case '0': return;
		default:
			cout << "\n\tERROR: Invalid Input.";
			break;

		}

		cout << "\n\n\t";
		system("pause");

	} while (true);

}

void RationalMenuA()
{
	cout << "\n\tA> A Rational Numbera";
	cout << "\n\t" << string(80, char(205));
	cout << "\n\t\t1. Enter the numerator";
	cout << "\n\t\t2. Enter the deminator";
	cout << "\n\t\t3. Display the rational number";
	cout << "\n\t\t4. Normalize the rational number";
	cout << "\n\t\t5. Negate the rational number";
	cout << "\n\t\t6. Add (+) the rational number with a constant";
	cout << "\n\t\t7. Subtract (-) the rational number with a constant";
	cout << "\n\t\t8. Multiply (*) the rational number with a constant";
	cout << "\n\t\t9. Divide (/) the rational number with a constant";
	cout << "\n\t" << string(80, char(196));
	cout << "\n\t\t0. Return";
	cout << "\n\t" << string(80, char(205));
}

void RationalFunctionA()
{
	Rational R1;
	Rational R2;
	Rational R3;


	do
	{
		system("cls");

		try
		{
			RationalMenuA();
			switch (inputInteger("\n\tOption: "))
			{
			case 1:
			{
				int n = inputInteger("\n\tEnter the value for the numerator: ");

				R1.setNumerator(n);

			}

			break;
			case 2:
			{
				int d = inputInteger("\n\tEnter the value for the denominator: ");

				R1.setDenominator(d);

			}
			break;

			case 3:
			{
				cout << "\n\tRational number R1: " << R1.getNumerator() << "/" << R1.getDenominator();
			}
			break;
			case 4:
			{
				cout << "\n\tNormalized rational number R2 (a copy of R1)";
				R1.normalize();
				cout << "\n\t" << R1;
			}
			break;
			case 5:
			{
				R3.setNumerator(-1);
				R2 = R1 * R3;
				cout << "\n\t\tNegated rational number R2 (a copy of R1)";
				cout << "\n\n\t\t-(" << R1 << ") = " << R2;
			}
			break;
			case 6:
			{
				R3.setNumerator(inputInteger("\n\t\tEnter an integer value: "));
				R2 = R1 + R3;
				cout << "\n\n\t\tR2 + value\n" << "\t\t(" << R1 << ") + " << R3.getNumerator()
					<< " = " << R2;
				cout << "\n\n\t\tvalue + R2\n" << "\t\t" << R3.getNumerator() << " + (" << R1
					<< ") = " << R2;
			}
			break;
			case 7:
			{
				R3.setNumerator(inputInteger("\n\t\tEnter an integer value: "));
				R2 = R1 - R3;
				cout << "\n\n\t\tR2 - value\n" << "\t\t(" << R1 << ") - " << R3.getNumerator()
					<< " = " << R2;

				R2 = R3 - R1;
				cout << "\n\n\t\tvalue - R2\n" << "\t\t" << R3.getNumerator() << " - (" << R1
					<< ") = " << R2;
			}
			break;
			case 8:
			{
				R3.setNumerator(inputInteger("\n\t\tEnter an integer value: "));
				R2 = R1 * R3;
				cout << "\n\n\t\tR2 * value\n" << "\t\t(" << R1 << ") * " << R3.getNumerator()
					<< " = " << R2;

				cout << "\n\n\t\tvalue * R2\n" << "\t\t" << R3.getNumerator() << " * (" << R1
					<< ") = " << R2;

			}
			break;
			case 9:
			{
				R3.setNumerator(inputInteger("\n\t\tEnter an integer value: "));
				R2 = R1 / R3;
				cout << "\n\n\t\tR2 / value\n" << "\t\t(" << R1 << ") / " << R3.getNumerator()
					<< " = " << R2;

				R2 = R3 / R1;
				cout << "\n\n\t\tvalue / R2\n" << "\t\t" << R3.getNumerator() << " / (" << R1
					<< ") = " << R2;
			}
			break;
			case 0:
				return;

			default: cout << "\n\tERROR: Invalid Input";
			}

		}
		catch (const runtime_error& e)
		{
			cout << "\n\tERROR: " << e.what();
		}

		cout << "\n\n\t";
		system("pause");
	} while (true);

}


void RationalMenuB()
{
	cout << "\n\tB> Multiple Rational Numbers";
	cout << "\n\t" << string(80, char(205));
	cout << "\n\t\t1. Enter rational number R1";
	cout << "\n\t\t2. Enter rational number R2";
	cout << "\n\t\t3. Verify condition operators (==, !=, >=, >, <= and <) of R1 and R2";
	cout << "\n\t\t4. Evaluate arithmatic operators (+, - , * and /) of R1 and R2";
	cout << "\n\t\t5. Evaluate (3 * (R1 + R2) / 7) / (R2 - R1 / 9) >= 621/889";
	cout << "\n\t" << string(80, char(196));
	cout << "\n\t\t0. Return";
	cout << "\n\t" << string(80, char(205));
}

void RationalFunctionB()
{
	Rational R1;
	Rational R2;


	do
	{
		system("cls");

		try
		{
			RationalMenuB();
			switch (toupper(inputChar("\n\tOption: ")))
			{
			case '1':
			{
				int n = inputInteger("\n\tEnter the value for the numerator: ");
				int d = inputInteger("\n\tEnter the value for the denominator: ");

				R1.setNumerator(n);
				R1.setDenominator(d);

				R1.normalize();

				cout << "\n\tR1 = " << R1;


			}

			break;
			case '2':
			{
				int n = inputInteger("\n\tEnter the value for the numerator: ");
				int d = inputInteger("\n\tEnter the value for the denominator: ");

				R2.setNumerator(n);
				R2.setDenominator(d);

				R2.normalize();
				cout << "\n\tR2 = " << R2;


			}
			break;
			case '3':
			{
				cout << boolalpha;
				bool anyUndef = R1.isUndefined() || R2.isUndefined();
				R1.normalize();
				R2.normalize();
				cout << "\n\n\tR1 == R2 -> (" << R1 << ") == (" << R2 << ") ? " << (R1 == R2);
				cout << "\n\tR1 != R2 -> (" << R1 << ") != (" << R2 << ") ? " << (R1 != R2);
				cout << "\n\tR1 >= R2 -> (" << R1 << ")  >= (" << R2 << ") ? " << (R1 >= R2);
				cout << "\n\tR1  > R2 -> (" << R1 << ")  > (" << R2 << ") ? " << (R1 > R2);
				cout << "\n\tR1 <= R2 -> (" << R1 << ") <= (" << R2 << ") ? " << (R1 <= R2);
				cout << "\n\tR1 < R2 -> (" << R1 << ") < (" << R2 << ") ? " << (R1 < R2);
			}
			break;
			case '4':
			{
				R1.normalize();
				R2.normalize();
				cout << "\n\tAddition     : R1 + R2 -> (" << R1 << ") + (" << R2 << ") = " << (R1 + R2);
				cout << "\n\tSubtraction  : R1 - R2 -> (" << R1 << ") - (" << R2 << ") = " << (R1 - R2);
				cout << "\n\tMutiplication: R1 * R2 -> (" << R1 << ") * (" << R2 << ") = " << (R1 * R2);

				cout << "\n\tDivision     : R1 / R2 -> (" << R1 << ") / (" << R2 << ") = " << (R1 / R2);
			}
			break;
			case '5':
			{
				R1.normalize();
				R2.normalize();
				cout << "\n\t\tR1 = " << R1;
				cout << "\n\t\tR2 = " << R2;
				cout << "\n\t\tR3 = 621/889";
				cout << "\n\n\t\tEvaluating expression..." << "\n\t\t\t   (3 * (R1 + R2) / 7) / (R2 - R1 / 9) >= 621/889 ?";

				// step #1: (R1 + R2) and (R1 / 9), propagate undefined via if / else
				Rational sum12;
				if (R1.isUndefined() || R2.isUndefined())
					sum12 = Rational(0, 0);            // undefined
				else
					sum12 = R1 + R2;

				Rational R1div9;
				if (R1.isUndefined())
					R1div9 = Rational(0, 0);           // undefined
				else
					R1div9 = R1 / Rational(9, 1);      // 9 != 0, so safe

				cout << "\n\t\t  Step #1: (3 * (" << sum12 << ") / 7) / (R2 - (" << R1div9 << ")) >= 621/889 ?";


				// ---------- step #2: leftPart = 3*(R1+R2)/7, rightDen = R2 - R1/9 ----------

				Rational leftPart;
				if (sum12.isUndefined())
					leftPart = Rational(0, 0);
				else
					leftPart = (Rational(3, 1) * sum12) / Rational(7, 1); // 7 != 0

				Rational rightDen;
				if (R2.isUndefined() || R1div9.isUndefined())
					rightDen = Rational(0, 0);
				else
					rightDen = R2 - R1div9;

				cout << "\n\t\t  Step #2: (" << leftPart << ") / (" << rightDen << ") >= 621/889 ?";

				// ---------- Step #3: wholeLeft = leftPart / rightDen ----------
				Rational wholeLeft;
				if (leftPart.isUndefined() || rightDen.isUndefined())
				{
					wholeLeft = Rational(0, 0);
				}
				else
				{
					// avoid division by zero (numerator==0 -> rightDen == 0)
					if (rightDen.getNumerator() == 0)
						wholeLeft = Rational(0, 0);
					else
						wholeLeft = leftPart / rightDen;
				}

				cout << "\n\t\t  step #3: " << wholeLeft << " >= 621/889 ?";

				// ---------- step #4: Right side ----------
				Rational rightSide(621, 889);
				cout << "\n\t\t  step #4: " << wholeLeft << " >= " << rightSide << " ?";

				// ---------- step #5: final compare ----------
				// Your rule: if left side is undefined -> print false
				if (wholeLeft.isUndefined())
				{
					cout << "\n\t\t  step #5: false";
				}
				else
				{
					bool ans;
					if (wholeLeft >= rightSide)
						ans = true;
					else
						ans = false;
					cout << "\n\t\t  step #5: " << (ans ? "true" : "false");
				}
			}
			break;
			case '0':
				return;

			default: cout << "\n\tERROR: Invalid Input";
			}

		}
		catch (const runtime_error& e)
		{
			cout << "\n\tERROR: " << e.what();
		}

		cout << "\n\n\t";
		system("pause");
	} while (true);

}


void polynomialMenu()
{
	while (true)
	{
		polynomial p;
		system("cls");

		cout << "\n\tA polynomial is an expression consisting of variables(also called indeterminates) and";
		cout << "\n\tcoefficients, that involves only the operations of addition, substraction, multiplication";
		cout << "\n\tand non-negative integer exponentiation of variables";

		cout << "\n\n\t3>Polynomials";
		cout << "\n\t" << string(89, char(205));
		cout << "\n\t\tA> A Polynomial";
		cout << "\n\t\tB> Multiple Polynomials";
		cout << "\n\t" << string(89, char(196));
		cout << "\n\t\t0> return";
		cout << "\n\t" << string(89, char(205));

		switch (toupper(inputChar("\n\t\tOption: ", static_cast<string>("AB0"))))
		{
		case 'A':
			polynomial_optionA(p);
			break;
		case 'B':
			polynomial_optionB();
			break;
		case '0':
			cout << "\n";
			return;
		}

		cout << "\n";
		system("pause");
	}
	
}


void polynomial_optionA(polynomial &p)
{

	bool isCase2Active = false;

	while (true)
	{
		system("cls");

		cout << "\n\tA> Single Polynomial";
		cout << "\n\t" << string(80, char(205));
		cout << "\n\t\t1. Enter the number of terms";
		cout << "\n\t\t2. Specify the coefficients";
		cout << "\n\t\t3. Evaluate expression";
		cout << "\n\t\t4. Solve for the derivative";
		cout << "\n\t\t5. Solve for the integral";
		cout << "\n\t" << string(80, char(196));
		cout << "\n\t\t0> return";
		cout << "\n\t" << string(80, char(205));

		switch (inputInteger("\n\t\tOption: ", 0, 5))
		{
		case 1:
			p.setTerms(inputInteger("\n\t\tEnter the number of terms(1..100): ", 1, 100));
			isCase2Active = false;
			break;
		case 2:
		{
			if (p.getTerms() > 0)
			{
				cout << "\n";
				for (int i = p.getTerms() - 1; i > -1; i--)
				{
					double amount = inputDouble("\t\tEnter the coefficient for term #" + to_string(p.getTerms() - i) + ": ");

					p.add_to_coef(amount, i);
				}
				cout << "\n\t\tThe P(x) is entered: " << p << "\n";
				isCase2Active = true;
			}
			else
				cout << "\n\t\tERROR: 0 term. Please enter the number of terms\n";
		}
		break;

		case 3:
			if (p.getTerms() > 0 && isCase2Active)
			{
				cout << "\n\t\tP1(x) =" << p << "\n";
				double x = inputDouble("\n\t\tEnter the value of x to evaluate the polynomial: ");

				for (int i = p.getTerms() - 1; i > -1; i--)
				{
					if (i == 0)
						cout << "\n\t\t +";
					else
						cout << "\n\t\t  ";

					cout << setw(13) << setprecision(5)
						<< p.getCoefficient(i) * pow(x, i);

					cout << " <-" << setw(15) << fixed << setprecision(2)
						<< p.getCoefficient(i) << "x^" << i;
\
					cout.unsetf(ios::fixed); //take off the fixed.
				}
				cout << "\n\t\t" << string(40, char(196));
				cout << "\n\t\t  " << setw(13) << setprecision(5) << p.evaluate(x);
				cout << "\n";
			}
			else if (p.getTerms() == 0)
				cout << "\n\t\tERROR: 0 term. Please enter the number of terms\n";
			else
				cout << "\n\t\tERROR: expression. Please specify the coefficients.\n";
			break;
		case 4:
		{
			if (p.getTerms() > 0 && isCase2Active)
			{
				cout << "\n\t\tPolynomial(x) = " << p;
				polynomial d = p.derivative();
				cout << "\n\n\t\tDerivative    = " << d;
				cout << "\n";
			}
			else if (p.getTerms() == 0)
				cout << "\n\t\tERROR: 0 term. Please enter the number of terms\n";
			else
				cout << "\n\t\tERROR: expression. Please specify the coefficients.\n";
		}
			break;
		case 5:
		{
			if (p.getTerms() > 0 && isCase2Active)
			{
				cout << "\n\t\tPolynomial(x) = " << p;
				polynomial i = p.integral();
				cout << "\n\n\t\tIntegral      = " << i;
				cout << "\n";
			}
			else if (p.getTerms() == 0)
				cout << "\n\t\tERROR: 0 term. Please enter the number of terms\n";
			else
				cout << "\n\t\tERROR: expression. Please specify the coefficients.\n";
		}
			break;
		case 0:
			return;
		}

		cout << "\n";
		system("pause");
	}
}

void polynomial_optionB()
{
	system("cls");

	cout << "\n\tB> Two Polynomials";

	polynomial p1;
	polynomial p2;

	p1.setTerms(inputInteger("\n\t\tEnter the number of terms(1..100) for the first polynomial (P1): ", true));

	for (int i = p1.getTerms() - 1; i > -1; i--)
	{
		double amount = inputDouble("\t\t\tEnter the coefficient for term#" + to_string(p1.getTerms() - i) + ": ");

		p1.add_to_coef(amount, i);
	}
	cout << "\n\tThe first polynomial (P1) is entered: " << p1 << "\n";

	p2.setTerms(inputInteger("\n\t\tEnter the number of terms(1..100) for the first polynomial (P2): ", true));

	for (int i = p2.getTerms() - 1; i > -1; i--)
	{
		double amount = inputDouble("\t\t\tEnter the coefficient for term#" + to_string(p2.getTerms() - i) + ": ");

		p2.add_to_coef(amount, i);
	}
	cout << "\n\tThe second polynomial (P1) is entered: " << p2 << "\n";

	polynomial p3;

	p3 = p1 + p2;
	cout << "\n\tAddition of polynomials       -> P1 + P2 = " << p3;

	p3 = p1 - p2;
	cout << "\n\tSubtraction of polynomials    -> P1 - P2 = " << p3;

	p3 = p1 * p2;
	cout << "\n\tMultiplication of polynomials    -> P1 * P2 = " << p3;

	double constValue = inputDouble("\n\n\t\tEnter a constant value: ");
	cout << "\n\t";

	cout << fixed << setprecision(6);

	p3 = constValue * p1;

	cout << constValue << " * Polynomial(P1) = " << p3 << "\n\t";

	p3 = p2 * constValue;


	cout << fixed << setprecision(6);

	cout << "Polynomial(P2) * " << constValue << " = " << p3 << "\n";
}